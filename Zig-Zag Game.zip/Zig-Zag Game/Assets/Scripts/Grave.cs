﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Grave : MonoBehaviour {

    //Change
    void Update()
    {
        if(transform.position.y < -2){
            Destroy(gameObject);
        }
    }

}
