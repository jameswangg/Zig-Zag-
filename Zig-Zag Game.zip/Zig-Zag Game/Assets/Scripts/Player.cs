﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Player : MonoBehaviour
{

    private Rigidbody rigidBody;
    private bool ismovingright = false;

    [HideInInspector] public bool Canmove = true;

    [Header("速度")]
    [HideInInspector] public static float startSpeed = 3;
    public static float currentSpeed;//speed text

    [Space]

    [Header("particles")]
    [SerializeField] GameObject particle;
    [SerializeField] GameObject speedParticles;
    [SerializeField] GameObject slowParticles;
    [SerializeField] GameObject deathParticle;

    [Space]

    [Header("UI")]
    public Text scoreText;
    public Text scoreSpeed;
    public Text timerText;

    [Space]

    [Header("GameOver")]
    public bool gameDone = false;
    public GameObject gameOverUI;

    [Space]

    [Header("Point System")]
    private bool purplePoint = false;
    private bool redPoint = false;
    private bool bluePoint = false;
    private bool streakPoint = false;
    public GameObject redPointUI;
    public GameObject purplePointUI;
    public GameObject bluePointUI;
    public GameObject streakPointUI;

    //private variables
    //[HideInInspector] public static float startTime;//time text
    //[HideInInspector] public static float currentTime;

    //Scores and Statistics
    [HideInInspector] public static int startScore = 0;
    [HideInInspector] public static int currentScore;//score text
    [HideInInspector] public static float countUp; // must be float
    [HideInInspector] public static int startStreakScore = 20;
    [HideInInspector] public static int currentStreakScore;
    [HideInInspector] public static int gemsCurrentScore;
    [HideInInspector] public static int gemsStartScore = 0;

    [Space]

    public Text highscoreText;

    [HideInInspector] public static float highScore = ((currentScore * countUp) * (currentSpeed / 2f));

    void Start()
    {

        //Game not over
        gameDone = false;

        rigidBody = this.GetComponent<Rigidbody>();

        //speed 
        currentSpeed = startSpeed;
        currentScore = startScore;
        currentStreakScore = startStreakScore;
        gemsCurrentScore = gemsStartScore;

        //score
        scoreText.text = "得点：" + currentScore.ToString();
        scoreSpeed.text = "速度：" + currentSpeed.ToString();


        //time start
        countUp = 0;

        //high score
        highScore = 0;

        //save high score function
        highscoreText.text = PlayerPrefs.GetFloat("HighScore").ToString();
        PlayerPrefs.SetFloat("HighScore", highScore);

        //time
        //startTime = Time.time;
        //currentTime = startTime;

    }

    void Update()
    {

        if(gameDone){
            return;
        }

        if (Input.GetMouseButtonDown(0) && Canmove)//for movement
        {
            ChangeBoolean();
            ChangeDirection();
        }

        if (Physics.Raycast(this.transform.position, Vector3.down * 2) == false)//this is the thing that makes it fall
        {
            Falldown();//what does raycast do again?
        }

        if (transform.position.y < -1)
        {
            Dead();
        }

        if (currentSpeed <= 2)
        {
            //Speed Limiter
            currentSpeed = 2;
            SpeedControl();
        }

        if (currentScore <= 0) 
        {
            //Score Limiter
            currentScore = 0;
            RecordScore();
        }

        //timer function
        //float t = Time.time - startTime;

        //string minutes = ((int) t / 60).ToString();//minutes
        //string seconds = (t % 60).ToString("f2");//seconds

        //timerText.text = minutes + ":" + seconds;

        //timer
        countUp += Time.deltaTime;
        timerText.text = string.Format("{0:00:00}", countUp);

        //streak
        if(gemsCurrentScore >= currentStreakScore){
            
            streakPoint = true;
            streakPointUI.SetActive(true);
            currentStreakScore += 20;
            currentScore += 20;
            StartCoroutine(StreakDisable());

        }

    }

    private void Falldown()
    {
        Canmove = false;
        rigidBody.velocity = new Vector3(0f, -4f, 0f);//apply a force
    }

    void Dead()
    {
        //Destroy(gameObject);
        GameObject _deathParticle = Instantiate(deathParticle) as GameObject;
        _deathParticle.transform.position = this.transform.position;

        //Restart
        StartCoroutine(Restart());

    }

    IEnumerator Restart()
    {
        //restart function
        yield return new WaitForSeconds(2f);
        //SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        gameDone = true;
        gameOverUI.SetActive(true);
        //Time.timeScale = 0;
    }

    private void ChangeBoolean()//for the boolean
    {
        ismovingright = !ismovingright;//change the boolean
    }

    //動くやつ
    private void ChangeDirection()//when boolean changes 
    {
        
        if (ismovingright)
        {
            
            //if set to true move in this direction
            rigidBody.velocity = new Vector3(currentSpeed, 0f, 0f);//xyz

        }
        else
            //if boolean is false
            rigidBody.velocity = new Vector3(0f, 0f, currentSpeed);

    }

    public void OnTriggerEnter(Collider other)
    {
        //change
        if (other.gameObject.tag == "Speed")
        {

            Destroy(other.gameObject);

            //speed control
            currentSpeed += .5f;
            SpeedControl();

            //score control
            currentScore += 20;
            RecordScore();

            //Speed Particles
            SpeedParticles();

            AddGemPointScore();

            RedPoint();

        }

        //change
        if (other.gameObject.tag == "Slow")
        {

            Destroy(other.gameObject);

            //speed control
            currentSpeed -= .5f;
            SpeedControl();

            //score control
            currentScore -= 30;
            RecordScore();

            //Slow Particles
            SlowParticles();

            AddGemPointScore();

            BluePoint();

        }

        if (other.gameObject.tag == "Gem")
        {

            //destroy the gem
            Destroy(other.gameObject);

            Particles();

            AddScore();

            AddGemPointScore();

            PurplePoint();
        }
    }

    void AddGemPointScore(){

        gemsCurrentScore ++;

    }

    void AddScore(){
        
        currentScore += 10;
        RecordScore();

    }

    void Particles(){
        
        GameObject _particle = Instantiate(particle) as GameObject;//have comtrol of game object
        _particle.transform.position = this.transform.position;
        Destroy(_particle, 1f);//destroy after 1 second

    }

    void SpeedParticles(){

        GameObject _speedparticle = Instantiate(speedParticles) as GameObject;
        _speedparticle.transform.position = this.transform.position;
        Destroy(_speedparticle, 1f);

    }

    void SlowParticles(){

        GameObject _slowparticle = Instantiate(slowParticles) as GameObject;
        _slowparticle.transform.position = this.transform.position;
        Destroy(_slowparticle, 1f);

    }

    //points
    void RedPoint()
    {
        redPoint = true;
        redPointUI.SetActive(true);
        StartCoroutine(ReturnRedPoint());
    }

    IEnumerator ReturnRedPoint(){

        yield return new WaitForSeconds(0.35f);
        redPoint = false;
        redPointUI.SetActive(false);
    }


    void BluePoint()
    {
        bluePoint = true;
        bluePointUI.SetActive(true);
        StartCoroutine(ReturnBluePoint());

    }

    IEnumerator ReturnBluePoint(){

        yield return new WaitForSeconds(0.35f);
        bluePoint = false;
        bluePointUI.SetActive(false);

    }

    void PurplePoint()
    {

        purplePoint = true;
        purplePointUI.SetActive(true);
        StartCoroutine(ReturnPurplePoint());

    }

    IEnumerator ReturnPurplePoint()
    {

        yield return new WaitForSeconds(0.35f);
        purplePoint = false;
        purplePointUI.SetActive(false);
        
    }



    IEnumerator StreakDisable(){

        yield return new WaitForSeconds(2.5f);
        streakPoint = false;
        streakPointUI.SetActive(false);

    }

    //change
    public void RecordScore()
    {
        scoreText.text = "得点：" + currentScore.ToString();
    }

    void SpeedControl()
    {
        scoreSpeed.text = "速度：" + currentSpeed.ToString();
    }

}

//なんでこれがこうだ