﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Gameover : MonoBehaviour {
    
    [Header("Texts")]
    public Text overallScoreText;
    public Text overallSpeedText;
    public Text overallTimeScore;
    public Text totalScore;

    [Space]

    [Header("MainMenu")]
    public string menuSceneName = "Menu";

    [Space]

    [Header("Fader Function")]
    public FaderFunction faderFunction;


    private void Start()
    {
        
    }

    public void Update()
    {
        ScoreCalculator();
    }

    public void ScoreCalculator()
    {
        overallScoreText.text = "得点: " + Player.currentScore.ToString();
        overallSpeedText.text = "速度: " + Player.currentSpeed.ToString();
        overallTimeScore.text = "タイム計算: " + Player.countUp.ToString("0");
        totalScore.text = "最終スコア: " + ((Player.currentScore * Player.countUp) * (Player.currentSpeed / 2f)).ToString("0");


       
    }


    public void Redo(){
        
        //SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        //Time.timeScale = 1;
        faderFunction.FadeTo(SceneManager.GetActiveScene().name);

    }

    public void Menu(){
        
        Debug.Log("Menu");
        //SceneManager.LoadScene("Menu");
        //Time.timeScale = 1;
        faderFunction.FadeTo(menuSceneName);

    }
}
