﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Return : MonoBehaviour {

    [Header("Menu String")]
    public string menuSceneName = "Menu";

    public FaderFunction faderFunction;

    public void ReturntoMenu(){

        Debug.Log("Return To Menu");
        faderFunction.FadeTo(menuSceneName);

    }

}
