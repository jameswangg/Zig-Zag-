﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Menu : MonoBehaviour
{
    [Header("Level Strings")]
    public string LeveltoLoad = "Level";
    public string InstructionsLoaded = "Instructions";

    [Space]

    [Header("Fader Function Here")]
    public FaderFunction faderFunction;

    public void StartLevel()
    {
        Debug.Log("Game Start");
        Time.timeScale = 1;
        //SceneManager.LoadScene(LeveltoLoad);
        faderFunction.FadeTo(LeveltoLoad);
    }

    public void Instructions(){

        Debug.Log("Instructions Opened");
        Time.timeScale = 1;
        faderFunction.FadeTo(InstructionsLoaded);

    }

    public void Quitgame()
    {
        Debug.Log("Quit Game");
        Application.Quit();
    }
}