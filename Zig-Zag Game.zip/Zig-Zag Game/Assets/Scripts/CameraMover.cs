﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraMover : MonoBehaviour {

    [Header("Target Here")]
    [SerializeField] Transform target;

    Vector3 offset;

	void Start () {

        offset = target.transform.position - this.transform.position;//this is the distance between the target and the camera

	}
	
	void LateUpdate () {

        if (target.gameObject.GetComponent<Player>().Canmove)//wiht this if fall off the camera does not follow
       {
            Vector3 Requiredposition = target.transform.position - offset;
            this.transform.position = Vector3.Lerp(this.transform.position, Requiredposition, 1.5f);
        }
	}
}
