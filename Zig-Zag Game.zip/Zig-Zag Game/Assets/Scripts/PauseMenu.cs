﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PauseMenu : MonoBehaviour {

    [Header("Pause Label")]
    public GameObject ui;

    [Space]

    [Header("MainMenu")]
    public string menuSceneName = "Menu";

    [Space]

    [Header("Fader Function")]
    public FaderFunction faderFunction;

	void Update () {
		
        if(Input.GetKeyDown(KeyCode.Escape) || Input.GetKeyDown(KeyCode.P))
        {
            Toggle();
        }
	}

    public void Toggle()
    {

        ui.SetActive(!ui.activeSelf);

        if(ui.activeSelf)
        {
            Time.timeScale = 0f;
        }else{
            Time.timeScale = 1f;
        }
    }

    public void Resume(){

        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);


    }

    public void Menu()
    {
        Debug.Log("Menu");
        Toggle();
        faderFunction.FadeTo(menuSceneName);
        //SceneManager.LoadScene("Menu");
    }

}
