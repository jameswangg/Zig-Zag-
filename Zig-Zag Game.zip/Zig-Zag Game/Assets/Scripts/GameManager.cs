﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour {

    //public variables
    [Header("Gems and Platforms")]
    [SerializeField]GameObject platform;

    [Space]

    [Header("Gems")]
    [SerializeField]GameObject gems;
    [SerializeField]GameObject speedGems;
    [SerializeField]GameObject slowGems;


    //private variables
    Vector3 lastpos;
    private float size;

	void Start () {

        size = platform.transform.localScale.x;//localscale {get; set;}
        lastpos = platform.transform.position;

        for (int x = 0; x < 6; x++){//23
            SpawnZ();
        }

        InvokeRepeating("SpawnPlatform", 2f, 0.2f);//every 2 seconds

	}
	
    private void SpawnPlatform(){


        int random = Random.Range(0, 6);//between 6

        //change
        int gemsrandom = Random.Range(0, 9);//gems spawning
        //change

        if (random < 3){
            SpawnX();
        }
        
        if(random >= 3){
            SpawnZ();
        }

        //change
        if (gemsrandom == 1)
        {
            SpawnGems();
        }
        else if (gemsrandom == 2)
        {
            SpawnGems();
        }
        else if (gemsrandom == 5)
        {
            SpawnSpeedGems();
        }
        else if (gemsrandom == 8)
        {
            SpawnSlowGems();
        }
        //change
    }

    private void SpawnGems()
    {
        //Instantiate(gems, lastpos + Vector3.up, Quaternion.identity);

        Instantiate(gems, lastpos + new Vector3(0f, 0.7f, 0f), gems.transform.rotation);

        //last pos = means our platform position
        //vector3.up is get instatiated above the platform
        //quaternion identity is default rotation
    }

    //change
    private void SpawnSpeedGems(){

        Instantiate(speedGems, lastpos + new Vector3(0f, 0.7f, 0f), speedGems.transform.rotation);

    }

    //change
    private void SpawnSlowGems(){
        
        Instantiate(slowGems, lastpos + new Vector3(0f, 0.7f, 0f), slowGems.transform.rotation);

    }

    private void SpawnX(){
        
        GameObject _platform = Instantiate(platform) as GameObject;//instantiate this platform and get stored into _platfrom
        _platform.transform.position = lastpos + new Vector3(size, 0f, 0f);//adding transform of the platform by the size
        lastpos = _platform.transform.position;

    }

    private void SpawnZ(){

        GameObject _platform = Instantiate(platform) as GameObject;//instantiate this platform and get stored into _platfrom
        _platform.transform.position = lastpos + new Vector3(0f, 0f, size);//adding transform of the platform by the size
        lastpos = _platform.transform.position;

    }
}
