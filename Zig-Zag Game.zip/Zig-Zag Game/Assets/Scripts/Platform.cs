﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Platform : MonoBehaviour
{


    private void OnTriggerEnter(Collider other)
    {
        Debug.Log("Collision function enterpod");

        if (other.gameObject.tag == "Player")
        {
            Debug.Log("Falldown called");
            Invoke("FallDown", 1f);//invoke for 2 seconds
        }
    }

    private void FallDown()
    {
        this.GetComponentInParent<Rigidbody>().isKinematic = false;
        //Destroy(this.transform.parent.gameObject, 2f);
    }

}

