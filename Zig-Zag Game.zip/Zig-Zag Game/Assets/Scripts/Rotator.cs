﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rotator : MonoBehaviour {

    //Change
    [Header("Variables")]
    public float speed;

    void Start()
    {
        speed = 4f;
    }

    void Update ()
    {
        transform.Rotate(new Vector3(15f, 30f, 45f) * speed * Time.deltaTime);
 
	}
}
